"use strict";
exports.__esModule = true;
var protractor_1 = require("protractor");
var EnvData = require('./testData/EnvData');
exports.config =
    {
        /*capabilities: {'directConnect': true,
            'browserName': 'chrome',
            chromeOptions: {    args: ["--incognito",'disable-extensions','disable-infobars',]}
        },*///or below
    directConnect: true,
    //    capabilities: {'browserName': 'firefox'},//uncomment this to run on firefox.
        framework: 'jasmine',  
/*multiCapabilities: [
   //to execute in parallel
    {
        "browserName": "chrome",'goog:chromeOptions': {w3c: false},
        specs: ['.navigate to test case1.js']
    },
    {
        "browserName": "chrome",'goog:chromeOptions': {w3c: false},
        specs: ['.navigate to test case2.js']
    },
    {
        "browserName": "chrome",'goog:chromeOptions': {w3c: false},
        specs: ['.navigate to test case3.js']
    },
],    */
        suites: {
            WEATHER: [
                    './testSuite/*.js'
            ]
        }, 
        jasmineNodeOpts: {
            defaultTimeoutInterval: 1440000
        },
        onPrepare: function () {
            protractor_1.browser.ignoreSynchronization = true;
            protractor_1.browser.driver.manage().window().maximize();
            protractor_1.browser.driver.get(EnvData.baseurl.weatherurl);
            var EC = protractor.ExpectedConditions;

     var AllureReporter=require('jasmine-allure-reporter');
     jasmine.getEnv().addReporter(new AllureReporter({
       resultsDir: 'allure-results'
        }));
        jasmine.getEnv().afterEach(function(done){
            browser.takeScreenshot().then(function (png) {
              allure.createAttachment('Screenshot', function () {
                return Buffer.from(png, 'base64')//return new Buffer(png, 'base64')
              }, 'image/png')();
              done();
            })
          });     
        },     
        onComplete: function () {
            console.log("All done");
        }
    };
