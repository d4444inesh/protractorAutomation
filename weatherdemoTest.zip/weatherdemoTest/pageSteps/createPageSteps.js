//import { instances_path } from '../../pages/instances_path.js'
var instances_pathAccess = require('../pageInstances/instances_path.js');  
var method = instances_pathAccess.method;
var variables = instances_pathAccess.globalVariable; 
//const JSON = require('circular-json');
var createPageSteps = function()
{
    var EC = protractor.ExpectedConditions;
    this.system_temperature = function(){
        $("#temperature").getText().then(function (temp) {
            console.log("temperature is "+temp); 
            if(temp>35){
                element(by.buttonText("Buy moisturizers")).click();
                var tiles = 'Moisturizers';
                method.moisturize(tiles).getText().then(function(text1) {
                element(by.buttonText("Buy moisturizers")).click();
                console.log("description : "+text1);
                });
            }
            else
            {
                var tiless = 'Sunscreens';
                method.suncream(tiless).getText().then(function(text2) {
                element(by.buttonText("Buy sunscreens")).click();
                console.log("description"+text2);
            });
            }         
    });
    };
    this.system_product = function(){
        element(by.css(".btn.btn-primary")).click();
        variables.cart.click();
        browser.wait(EC.elementToBeClickable(variables.payCard), 3000);
        variables.payCard.click();
        
    };
    this.system_payment = function(){
        browser.wait(EC.elementToBeClickable(variables.email), 6000);
        variables.email.sendKeys("dinesh@gmail.com");
        variables.cardnumber.sendKeys(4242424242424242);
        variables.mmyy.sendKeys(022222)
        variables.cvv.sendKeys(022);
        
        
    };
}
module.exports = new createPageSteps();