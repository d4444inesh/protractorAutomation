var common_methods = function()
{

    this.scrollBottom = function()
    {
        browser.sleep(2000);
        browser.executeScript('window.scrollTo(0, document.body.scrollHeight);');
    }

    this.scrollTop = function()
    {
        browser.sleep(2000);
        browser.executeScript('window.scrollTo(0,0);');
    }

    this.elementvisibility = function(value)
    {
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(value),5000);
    }
	
    this.waitForPageToLoad = function()
    {
        browser.waitForAngularEnabled(true);
        browser.waitForAngular();
        browser.waitForAngularEnabled(false);
    }
}
module.exports = new common_methods();