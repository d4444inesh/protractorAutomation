
var createPageSteps = require('./../pageSteps/createPageSteps');
var EC = protractor.ExpectedConditions;
//var alert = require('selenium-webdriver')
describe("weathershopper python anywhere", function () {
    beforeAll(function () {
        browser.executeScript('window.scrollTo(0, 0);');
    });
    it("Step 1:get Temperature", function () {
        createPageSteps.system_temperature();
        
    });
    
    it("select item ", function(){
        createPageSteps.system_product();
       
    });
    it("make payment ", function(){
        createPageSteps.system_payment();
        
    });    
});


