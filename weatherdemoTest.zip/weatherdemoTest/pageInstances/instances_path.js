
var instances_method = function()
{
    this.moisturize = function(set1)
    {
        var descrn = element(by.xpath("//h3[text()='"+set1+"']/../p[@class='text-justify']"));
        return descrn;
    }
    this.suncream = function(set2)
    {
        var descrn = element(by.xpath("//h3[text()='"+set2+"']/../p[@class='text-justify']"));
        return descrn;
    }    
}
var globalVariable={
    
    cart : $("[onclick='goToCart()']"),
    payCard : element(by.buttonText("Pay with Card")),
    email : $(".Textbox-inputRow>input[type='email']"),
    cardnumber : $(".Textbox-inputRow input[placeholder='Card number']"),
    mmyy : $(".Textbox-inputRow input[placeholder='MM / YY']"),
    cvv : $(".Textbox-inputRow input[placeholder='CVC']"),
 }

module.exports = {
    method: new instances_method(),
    globalVariable
}